#include "game.hpp"
#include "loadtexture.hpp"

class GameObject {
public:
    int xpos;
    int ypos;
    float velocityY;
    float velocityX;
    SDL_Rect srcR, destR;
    SDL_Texture* objtex;

public:
    GameObject(const char* filename);
    GameObject(const char* filename,int x, int y);
    virtual ~GameObject();

    virtual void Update();
    void Render();
    void Gravity();
    void Stop();
    //void HandleCollision(GameObject *g);
};

class Player : public GameObject {
private:
    bool move = true;
public:

    Player(const char* filename);

    void Jump();
    void MoveRight();
    void MoveLeft();
    void Update(GameObject *g);
    bool returnmove();
    void setmove(bool &t);
    void Collision(GameObject *g);
    void CollisionY(GameObject *g);


};

class Objects : public GameObject
{
    public:
        Objects(const char* filename,int x, int y) : GameObject(filename,x, y)
        {

        };
        void Update();
};